Reddy Travels landing page recreated from the referenced public page structure. All WhatsApp CTAs use +91 96609 67314.

Popup added: opens automatically when the landing page loads. The green button opens WhatsApp on +91 96609 67314 with the requested pre-filled message. Popup can be closed with X, Escape, or by tapping outside it.

Close button fixed with a direct click handler plus JavaScript fallback. The X closes the popup and restores page scrolling.

Mobile fix: popup is responsive to small screens, uses dynamic viewport height, has a touch-friendly 48px close target, and prevents touch events from being swallowed.